import json, os, ipaddress, pprint, sys, logging, copy
from vpc_init import start_vpc
import ansible_runner
#global defintion
data = {}
logging.basicConfig(filename='xdp_app.log', format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=logging.DEBUG)

def load_data():
    json_dir = '../northbound'

    for file in os.listdir(json_dir):
        if file.endswith('.json'):
            with open(os.path.join(json_dir, file)) as f:
                tenant_data = json.load(f)
                local = split_data(tenant_data)
                data.update(local)
    logging.info("Data parsed from the northbound directory")
                

def input_checks():
    for tenant, tenant_data in data.items():
        seen_tenant_names = set()
        seen_vm_names = set()
        seen_networks = set()
        
        if tenant in seen_tenant_names:
            raise Exception("Duplicate tenant names")
    
        seen_tenant_names.add(tenant)

        for vm_name in tenant_data['VM']:
            name = vm_name["name"]
            if name in seen_vm_names:
                raise Exception("Duplicate VM names in same tenant")
            seen_vm_names.add(name)


        net_dict = {}
        for network_name, network_id in tenant_data['networks'].items():

            ipaddress.ip_network(network_id,False)
            
            if network_id == "192.168.1.0/24":
                raise Exception("Can't use reserved networks")
            
            if network_id in seen_networks:
                raise Exception("Duplicate network definition in same tenant")
            seen_networks.add(network_id)
            
            net_dict[tenant + network_name] = network_id
        
        tenant_data['networks'] = net_dict

        for vm in tenant_data["VM"]:
            changed_netlist = []
            for net in vm['network']:
                changed_netlist.append(tenant + net)
            
            vm['network'] = changed_netlist
        '''
        for vm in tenant_data["VM"]:
            
            for net in vm['network']:
                print(net)
            
                changed_netlist.append(tenant + net)
            vm['network'] = changed_netlist
            '''
    logging.info("Northbound data parsing checks completed")
    return True

def update_data():
    for tenant,tenant_data in data.items():
        tenant_data["gateway_router"] = {}
        tenant_data["gateway_router"].update(
            {"name" : "test-cgw-" + tenant})
        
        net_list = []
        for network_id in tenant_data['networks'].keys():
            net_list.append(network_id)
        
        tenant_data["gateway_router"].update(
            {"network_list" : net_list})
        
        ip_list = []
        for network_id in tenant_data["gateway_router"]["network_list"]:
            ip_list.append(    
                    tenant_data["networks"][network_id]
            )

        tenant_data["gateway_router"].update(
            {"ip_list": ip_list})
        
        #Statically add pgw-net for connectivity to internet
        tenant_data["gateway_router"]["network_list"].append("pgwnet")
        logging.info("Data modules updated")

def write_data():
    with open("data/tenant_parsed.json", 'w') as f:    
        #pprint.pprint(data)
        json.dump(data,f,indent=6) 
        logging.info("Data modules saved to data/parsed.json")

def state_add():
    for tenant in data:
        for vm in data[tenant]['VM']:
            vm['state'] = 'down'
        data[tenant]['gateway_router']['state']= 'down'

def split_data(tenant_data):
    data2 = copy.deepcopy(tenant_data)
    data3 = copy.deepcopy(tenant_data)

    tenant_name = list(tenant_data.keys())[0]
    for tenant, details in data2.items():
        details['VM'] = []

    for tenant_new, details_new in data3.items():
        details_new['VM'] = []

    network_dict = dict.fromkeys(tenant_data[tenant_name]['networks'],0)
    print(tenant_data)
    for vm in tenant_data[tenant_name]['VM']:
        print(vm)
        for networks in vm['network']:
            if network_dict[networks] >= 2:
                data3[tenant_name]['VM'].append(vm)
            else:
                data2[tenant_name]['VM'].append(vm) 
            network_dict[networks] +=1
    with open("../northbound/remote" + tenant_name +".json", "w") as f_local:
        json.dump(data3, f_local, indent=4)
    with open("../northbound/"+tenant_name+".json", "w") as f_remote:
        json.dump(data2, f_remote, indent=4)

    #copy the data to the remote host machine

    r = ansible_runner.run(private_data_dir='../southbound', playbook='remote_run.yml', quiet=True)

    if r.rc == 0:
        logging.info(f"Transferring the files to the remote host was successfull")
    else:
        logging.info(f"Transferring the files to the remote host was successfull")

    return data2



def main():
    try:
        load_data()
        input_checks()
        update_data()
        state_add()
        write_data()
        start_vpc()
    except Exception as e:
        print(e)
        sys.exit(0)

if __name__ == "__main__":
    main()
