import yaml
import ansible_runner
import json
import pprint
import pexpect
import time
import logging
from utils import *


logging.basicConfig(filename='xdp_app.log', format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=logging.DEBUG)

def create_vm(network:str,port:str) -> None:
#Create the CGW router VM instance based on the inputs

    var = {"bridge" : network, "interface" : network[-2:], "port": port, "local_tunnel_ip": "192.168.1.231" , "remote_tunnel_ip": "192.168.1.80"}

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)

    r = ansible_runner.run(private_data_dir='../southbound', playbook='vxlan_create.yml')

    if r.rc == 0:
        logging.info(f"Vxlan end point creation was successfull for {network}")
        return 1
    else:
        logging.info(f"Vxlan creation was not successful for {network}")
        return 0


create_vm("tenant10tenet1","4793")
