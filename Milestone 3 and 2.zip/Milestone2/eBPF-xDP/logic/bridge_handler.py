import yaml
import ansible_runner
import json
import pprint
import logging

logging.basicConfig(filename='xdp_app.log', format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=logging.DEBUG)
def create_bridge(tenant_name: str, network_name: list) -> None:
    for i in range(len(network_name)):

        var = {"network": network_name[i], "bridge": network_name[i]}
        print(var)

        with open('../southbound/vars.yml', 'w') as f:
            yaml.dump(var, f)
            r1 = ansible_runner.run(private_data_dir='../southbound', playbook='bridge_create.yml', quiet=True)
            if r1.rc == 0:
                logging.info(f"Bridge creation was successful for {network_name[i]}")
            else:
                logging.info(f"Bridge creation was not successful for {network_name[i]}")
            r2 = ansible_runner.run(private_data_dir='../southbound', playbook='network_create.yml', quiet=True)
            if r2.rc == 0:
                logging.info(f"Network creation was successful for {network_name[i]}")
            else:
                logging.info(f"Network creation was not successful for {network_name[i]}")



def delete_bridge(tenant_name: str, network_name: list) -> None:
    for i in range(len(network_name)):

        var = {"network_name" : network_name[i], "bridge_name": network_name[i]}
        with open('../southbound/vars.yml', 'w') as f:
            yaml.dump(var, f)
            r1 = ansible_runner.run(private_data_dir='../southbound', playbook='network_delete.yml', quiet=True)
            if r1.rc == 0:
                logging.info(f"Bridge deletion was successful for {network_name[i]}")
            else:
                logging.info(f"Bridge deletion was not successful for {network_name[i]}")
            r2 = ansible_runner.run(private_data_dir='../southbound', playbook='bridge_delete.yml', quiet=True)
            if r2.rc == 0:
                logging.info(f"Network deletion was successful for {network_name[i]}")
            else:
                logging.info(f"Network deletion was not successful for {network_name[i]}")

            


'''
with open("data/tenant_parsed.json") as f:
    data = json.load(f)
   # pprint.pprint(data)
    for tenant in data.keys():
        create_bridge(tenant, data[tenant]["gateway_router"]["network_list"])
        delete_bridge(tenant, data[tenant]["gateway_router"]["network_list"])
'''
