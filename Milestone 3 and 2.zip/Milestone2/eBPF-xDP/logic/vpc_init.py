import json, pprint, time, logging
from bridge_handler import *
from gateway_handler import create_cgw_router
from vm_handler import *

data = {}

def start_vpc() -> None:
    with open("data/tenant_parsed.json") as f:
        global data 
        data = json.load(f) 
        pprint.pprint(data)
        create_pgw()
        create_tenant_networks()
        create_tenant_gateways()
        create_tenant_vms()
        #delete_tenant_vms()
    with open("data/tenant_parsed.json", "w") as f:
        json.dump(data, f, indent=4)

def create_pgw() -> None:
    create_bridge("pgw",["pgwnet"])
    pgw_defintion = {
        "name": "pgw-test17", "network_list": ["pgwnet"],"ip_list": ["192.168.1.0/24"]}
    create_cgw_router(pgw_defintion, "pgw")
    #time.sleep(300)
    #delete_bridge("pgw",["net"])

def create_tenant_networks():
    for tenant, tenant_data in data.items():
        create_bridge(tenant, list(tenant_data['networks'].keys()))

def create_tenant_gateways():
    for tenant, tenant_data in data.items():
        create_cgw_router(tenant_data["gateway_router"],"cgw")

def create_tenant_vms():
    for tenant, tenant_data in data.items():
        for vm in tenant_data["VM"]:
            if vm['state'] == "down":
                vm_param = {
                    "name":vm['name'] ,
                    "network_list":vm["network"],
                    "vcpu":vm.get("vcpu",1),
                    "memory":vm.get("memory",2097152)
                }
                r = create_vm(vm_param)
                if r == 1:
                    vm['state'] = 'up'

def delete_tenant_vms():
    for tenant, tenant_data in data.items():
        for vm in tenant_data["VM"]:
            if vm['state'] == "up":
                r = delete_vm(vm['name'])
                if r == 1:
                    vm['state'] = 'down'


def test_network_creation():
    create_cgw_router({
                  "name": "cgw-tenant3",
                  "network_list": [
                        "testtenant1",
                        "testtenant2",
                        "pgwnet"
                  ],
                  "ip_list": [
                        "192.168.15.0/24",
                        "192.168.20.0/24"
                  ]
            },"cgw")

#test_network_creation()
