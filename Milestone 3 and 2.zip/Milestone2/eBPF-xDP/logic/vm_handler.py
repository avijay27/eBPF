import yaml
import ansible_runner
import json
import pprint
import pexpect
import time
import logging
from utils import *

VM_PASSWORD = 'test'
VM_USERNAME = 'test'
logging.basicConfig(filename='xdp_app.log', format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=logging.DEBUG)

def create_vm(vm_data: dict) -> None:
#Create the CGW router VM instance based on the inputs

    var = {"vm_name" : vm_data["name"], "networks" : vm_data["network_list"], "device_type": "vm", "vcpu": vm_data["vcpu"] , "memory": vm_data["memory"]}

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)
    
    r = ansible_runner.run(private_data_dir='../southbound', playbook='vm_create.yml', quiet=True)

    if r.rc == 0:
        logging.info(f"VM creation was successful for {vm_data['name']}")
        return 1
    else:
        logging.info(f"VM creation was not successful for {vm_data['name']}")
        return 0


def configure_vm(vm_data: dict) -> None:

    def configure_ssh():

        print(">> Console session started for the VM : " + vm_data["name"])
        child = pexpect.spawnu("virsh console " + vm_data["name"] + " --force")
        time.sleep(2)
        child.sendline(VM_USERNAME)
        time.sleep(2)
        child.sendline(VM_PASSWORD)
        time.sleep(2)
        child.sendline("sudo su")
        time.sleep(2)
        child.sendline(VM_PASSWORD)
        print(">> Configuring SSH server ")
        child.sendline('sudo apt install --assume-yes openssh-server')
        time.sleep(20)
        print(">> SSH configuration complete")


    time.sleep(90)
    print("Starting configuration on the client")
    configure_ssh()

def delete_vm(vm_name: str) -> None:
    var = {"vm_name": vm_name}
    print(var)

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)
        r = ansible_runner.run(private_data_dir='../southbound', playbook='vm_delete.yml', quiet=True)
        if r.rc == 0:
            logging.info(f"VM deletion was successful for {vm_name}")
            return 1
        else:
            logging.info(f"VM deletion was not successful for {vm_name}")
            return 0





'''
with open("data/tenant_parsed.json") as f:
    data = json.load(f)
    for tenant in data.keys():
        for vms in data[tenant]["VM"]:
            params = {"name": vms, "network_list":data[tenant]["VM"][vms]['network'],"vcpu":data[tenant]["VM"][vms]['vcpu'],"memory":data[tenant]["VM"][vms]['memory']}
            print(params)
            create_vm(params)
            delete_vm(params["name"])
'''
