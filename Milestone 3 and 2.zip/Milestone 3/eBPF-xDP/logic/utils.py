import subprocess
import ipaddress, logging

def get_dhcp_lease(vm_name: str, network_name: str) -> list:
    try:
        cmd = "virsh net-dhcp-leases " + network_name + " | grep -i \'" + vm_name + "\' | awk \'{print $5}\'"
        ip = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE).stdout.read().decode("utf-8")
        logging.debug("IP address identified for {vm_name} : {ip_address}".format(vm_name = vm_name, ip_address=str(ip)))
        return [ipaddress.ip_network(ip[:-1],False),ip.split('/')[0]]

    except Exception as e:
        return None

def generate_host_file(ip: str, file: str) -> None:
    host_data = ip + " ansible_host=" + ip + " ansible_password=test ansible_sudo_pass=test ansible_user=test"
    with open(file, 'w') as f:
        f.write(host_data)
    logging.debug("Hostfile generated for {ip_address}".format(ip_address=ip))
    return None