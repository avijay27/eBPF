import json, os, ipaddress, pprint, sys, logging
from vpc_init import start_vpc
from threading import *
from health_check import *

#global defintion
data = {}
logging.basicConfig(filename='xdp_app.log', format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p', level=logging.DEBUG)

def load_data():
    json_dir = '../northbound'

    for file in os.listdir(json_dir):
        if file.endswith('.json'):
            with open(os.path.join(json_dir, file)) as f:
                tenant_data = json.load(f)
                data.update(tenant_data)
    logging.info("Data parsed from the northbound directory")
                

def input_checks():
    for tenant, tenant_data in data.items():
        seen_tenant_names = set()
        seen_vm_names = set()
        seen_networks = set()
        
        if tenant in seen_tenant_names:
            raise Exception("Duplicate tenant names")
    
        seen_tenant_names.add(tenant)

        for vm_name in tenant_data['VM']:
            name = vm_name["name"]
            if name in seen_vm_names:
                raise Exception("Duplicate VM names in same tenant")
            seen_vm_names.add(name)


        net_dict = {}
        for network_name, network_id in tenant_data['networks'].items():

            ipaddress.ip_network(network_id,False)
            
            if network_id == "192.168.1.0/24":
                raise Exception("Can't use reserved networks")
            
            if network_id in seen_networks:
                raise Exception("Duplicate network definition in same tenant")
            seen_networks.add(network_id)
            
            net_dict[tenant + network_name] = network_id
        
        tenant_data['networks'] = net_dict

        for vm in tenant_data["VM"]:
            changed_netlist = []
            for net in vm['network']:
                changed_netlist.append(tenant + net)
            
            vm['network'] = changed_netlist
        '''
        for vm in tenant_data["VM"]:
            
            for net in vm['network']:
                print(net)
            
                changed_netlist.append(tenant + net)
            vm['network'] = changed_netlist
            '''
    logging.info("Northbound data parsing checks completed")
    return True

def update_data():
    for tenant,tenant_data in data.items():
        tenant_data["gateway_router"] = {}
        tenant_data["gateway_router"].update(
            {"name" : "test-cgw-" + tenant})
        
        net_list = []
        for network_id in tenant_data['networks'].keys():
            net_list.append(network_id)
        
        tenant_data["gateway_router"].update(
            {"network_list" : net_list})
        
        ip_list = []
        for network_id in tenant_data["gateway_router"]["network_list"]:
            ip_list.append(    
                    tenant_data["networks"][network_id]
            )

        tenant_data["gateway_router"].update(
            {"ip_list": ip_list})
        
        #Statically add pgw-net for connectivity to internet
        tenant_data["gateway_router"]["network_list"].append("pgwnet")
        logging.info("Data modules updated")

def write_data():
    with open("data/tenant_parsed.json", 'w') as f:    
        pprint.pprint(data)
        json.dump(data,f,indent=6) 
        logging.info("Data modules saved to data/parsed.json")

def main():
    try:
      while True:
        user_input = input(">> ")

        if user_input.lower() == 'q':

          break

        elif user_input.lower() == 'start':

          load_data()
          input_checks()
          update_data()
          write_data()
          start_vpc()

        elif user_input.lower() == 'monitor':

          T = Thread(target=health_check, daemon=True)
          T.start()

        elif user_input.lower() == 'h':

          print("Options [monitor][start][q]")

        else:

          continue

    except Exception as e:
        print(e)
        sys.exit(0)

if __name__ == "__main__":
    main()

