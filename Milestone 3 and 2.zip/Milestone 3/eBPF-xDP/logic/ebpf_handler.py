import json,ansible_runner
from utils import *

def ping_tree():
  with open("data/tenant_parsed.json") as f:
    data = json.load(f)

  for key,value in data.items():
    gw_name = (value["gateway_router"]["name"])
    cgw_ip = get_dhcp_lease(gw_name,"default")
    generate_host_file(cgw_ip[1], "../southbound/inventory")
    ansible_runner.run(private_data_dir='../southbound', playbook='ebpf_tracer.yml', verbosity = 1)

def create_ebpf_monitor_container():
  ansible_runner.run(private_data_dir='../southbound', playbook='ebpf_container.yml', verbosity = 1)
