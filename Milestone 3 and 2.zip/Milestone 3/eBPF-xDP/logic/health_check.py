import json
import subprocess,time
from container_handler import *

def health_check():
  while True:
   # Load the JSON file into a dictionary
   # with open('/home/csc792/eBPF-xDP/logic/data/tenant_parsed.json', 'r') as f:
   with open('data/tenant_parsed.json', 'r') as f:
        data = json.load(f)

    # Loop through each tenant
   for tenant in data:
        # Loop through each VM in the tenant
        for vm in data[tenant]['VM']:
            # Get the name of the VM
            vm_name = vm['name']

            # Check if the VM is already running
            if vm_name.encode() in subprocess.check_output(['sudo', 'docker', 'ps', '--format', '{{.Names}}']).split():
                logging.debug(f'HEALTH-CHECKER: {vm_name} is active/running.')
            else:
                logging.debug(f'HEALTH-CHECKER: {vm_name} is being repaired')
                # Call the create_vm() function with the specified parameters
                cont_param = {
                    "name": vm_name,
                    "network_list": vm["network"]
                }
                create_container(cont_param)
   time.sleep(60)


#time.sleep(5)
#print("Health checker running")
#health_check() # call the function to run it

