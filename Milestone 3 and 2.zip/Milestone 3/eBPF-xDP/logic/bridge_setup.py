import yaml
import ansible_runner


def create_bridge(details: dict) -> None:
#Create the CGW router VM instance based on the inputs

    var = details

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)

    r1 = ansible_runner.run(private_data_dir='/home/csc792/eBPF-xDP/southbound', playbook='bridge_create.yml')
    r2 = ansible_runner.run(private_data_dir='/home/csc792/eBPF-xDP/southbound', playbook='network_create.yml')

    if(r1 == 0 and r2 == 0):
        return 0
    
    return 1

'''
def main():
    create_bridge({"bridge":"t1","network":"int"})

if __name__ == '__main__':
    main()
'''
