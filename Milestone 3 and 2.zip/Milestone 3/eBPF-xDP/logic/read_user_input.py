import json
import os
import ipaddress
json_dir = '../northbound'

filename = 'tenant_information.json'





with open(filename, 'w') as f:
   f.write('[')

# Create a dictionary to store the combined data
combined_data = {}
#get the data and store it in the file
files = os.listdir(json_dir)
num_files = len(files)
count = 0
for file in os.listdir(json_dir):
    if file.endswith('.json'):
        with open(os.path.join(json_dir, file)) as f:
            data = json.load(f)
            #print(data)

# pretty print :)

    with open(filename, 'a') as f:
        json.dump(data, f, indent=4)
        count = count + 1
        if (count == num_files):
            break
        else:

            f.write(',')
 # for the json format           
with open(filename, 'a') as f:
    f.seek(0,2)
    f.write(']')
print(data)
ip_address_list = []
vm_name_list = []

# reading the file for various use-cases
with open(filename, 'r') as f:
    data = json.load(f)

#have a list of ip addresses and vm names
    for d in data:
        for network_address in d["networks"].values():

            ip_address_list.append(network_address)
        for vm_names in d["VM"].keys():
            vm_name_list.append(vm_names)


#     Convert the IP addresses in the list to ipaddress objects
def subnet_overlap(lst):
    ip_objects = [ipaddress.ip_network(ip) for ip in lst]
#print(ip_address_list)
    # Sort the IP addresses in ascending order
    ip_objects.sort()

    # Check for overlap between adjacent subnets
    for i in range(len(ip_objects)-1):
        if ip_objects[i].overlaps(ip_objects[i+1]):

            with open(filename, "w") as f:
                f.write("")
    if os.path.getsize(filename) == 0:
        #raise Exception("subnets cannot overlap")
        print("subnet overlap")
    else:
        return


ip_addresses = subnet_overlap(ip_address_list)
print(ip_addresses)
def common_tenant_name(lst):
    for i in range(len(vm_name_list)):
        for j in range(i+1, len(vm_name_list)):
            if vm_name_list[i] == vm_name_list[j]:
               # print("common tenant names, deleting the file")
                with open(filename, "w") as f:
                    f.write("")

        if os.path.getsize(filename) == 0:
            #raise Exception("tenant names must be unique!")
            print("common tenant name")
        else:
            return

tenant_names = common_tenant_name(vm_name_list)
#print(tenant_names)

#def ip_format_check(lst):
 #   for ip in lst:
  #      try:
  #          ipaddress.ip_address(ip)
  #      except ValueError:
   #         with open(filename, 'w') as f:
   #             f.write("")
#        if os.path.getsize(filename) == 0:
         #raise Exception("ip format is wrong")
#            print("ip format check")
 #       else:
  #          return

# check if the json input satisfies the conditions, if it does, save it in a new file, else it will be an empty file

ip_addresses = subnet_overlap(ip_address_list)
tenant_names = common_tenant_name(vm_name_list)
#ip_format = ip_format_check(ip_address_list)
new_file = 'tenant_information_v2.json'
if os.path.getsize(filename) != 0:
    with open(filename, 'r') as f:
        data = f.read()


    with open(new_file, 'w') as f:
        
# Write the contents of the current file to the new file
        f.write("")
        f.write(data)

    print('Data saved to new file.')
else:

    print("not updating version2")
           

