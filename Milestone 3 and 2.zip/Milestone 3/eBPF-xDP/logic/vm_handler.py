import yaml
import ansible_runner
import json
import pprint
import pexpect
import time
from utils import *

VM_PASSWORD = 'test'
VM_USERNAME = 'test'

def create_vm(vm_data: dict) -> None:
#Create the CGW router VM instance based on the inputs

    var = {"vm_name" : vm_data["name"], "networks" : vm_data["network_list"], "device_type": "vm", "vcpu": vm_data["vcpu"] , "memory": vm_data["memory"]}

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)
    
    r = ansible_runner.run(private_data_dir='../southbound', playbook='vm_create.yml')


def configure_vm(vm_data: dict) -> None:

    def configure_ssh():

        print(">> Console session started for the VM : " + vm_data["name"])
        child = pexpect.spawnu("virsh console " + vm_data["name"] + " --force")
        time.sleep(2)
        child.sendline(VM_USERNAME)
        time.sleep(2)
        child.sendline(VM_PASSWORD)
        time.sleep(2)
        child.sendline("sudo su")
        time.sleep(2)
        child.sendline(VM_PASSWORD)
        print(">> Configuring SSH server ")
        child.sendline('sudo apt install --assume-yes openssh-server')
        time.sleep(20)
        print(">> SSH configuration complete")


    time.sleep(90)
    print("Starting configuration on the client")
    configure_ssh()

def delete_vm(vm_name: str) -> None:
    var = {"vm_name": vm_name}
    print(var)

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)
        ansible_runner.run(private_data_dir='../southbound', playbook='vm_delete.yml')




'''
with open("data/tenant_parsed.json") as f:
    data = json.load(f)
    for tenant in data.keys():
        for vms in data[tenant]["VM"]:
            params = {"name": vms, "network_list":data[tenant]["VM"][vms]['network'],"vcpu":data[tenant]["VM"][vms]['vcpu'],"memory":data[tenant]["VM"][vms]['memory']}
            print(params)
            create_vm(params)
            delete_vm(params["name"])
'''
