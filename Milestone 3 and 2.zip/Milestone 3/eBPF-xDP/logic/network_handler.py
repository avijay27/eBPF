import yaml
import ansible_runner
import json
import pprint

def create_network(tenant_name: str, network_name: list) -> None:
    for i in range(len(network_name)):
        
        var = {"network" : network_name[i], "bridge": tenant_name + '.' + network_name[i]}
        print(var)
  
        with open('../southbound/vars.yml', 'w') as f:
            yaml.dump(var, f)
        
            ansible_runner.run(private_data_dir='../southbound', playbook='network_create.yml')
    
def delete_network(network_name: list) -> None:
    for i in range(len(network_name)):
        
        var = {"network_name" : network_name[i]}
        with open('../southbound/vars.yml', 'w') as f:
            yaml.dump(var, f)
        
            ansible_runner.run(private_data_dir='../southbound', playbook='network_delete.yml')
        
            
    

with open("data/tenant_parsed.json") as f:
    data = json.load(f) 
   # pprint.pprint(data)
    for tenant in data.keys():
        create_network(tenant, data[tenant]["gateway_router"]["network_list"])
        delete_network(data[tenant]["gateway_router"]["network_list"])
