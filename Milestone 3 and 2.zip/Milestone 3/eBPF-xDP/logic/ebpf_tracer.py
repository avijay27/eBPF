#!/usr/bin/env python
# coding: utf-8

from socket import inet_ntop
from bcc import BPF
import ctypes as ct
from socket import inet_ntop, AF_INET, AF_INET6
from struct import pack
import datetime

bpf_text = '''
#include <bcc/proto.h>
#include <uapi/linux/ip.h>
#include <net/inet_sock.h>
#include <uapi/linux/icmp.h>

#define ROUTE_EVT_IF 1

#define member_read(destination, source_struct, source_member)                 \
  do{                                                                          \
    bpf_probe_read(                                                            \
      destination,                                                             \
      sizeof(source_struct->source_member),                                    \
      ((char*)source_struct) + offsetof(typeof(*source_struct), source_member) \
    );                                                                         \
  } while(0)


struct route_evt_t {

    /* Routing information */
    char ifname[IFNAMSIZ];
    u64 ip_version;
    u64 saddr[2];
    u64 daddr[2];
    u64 icmptype;

};

BPF_PERF_OUTPUT(route_evt);


static inline int do_trace(void* ctx, struct sk_buff* skb)
{
    // Built event for userland
    struct route_evt_t evt = {};
    // Get device pointer, we'll need it to get the name and network namespace
    struct net_device *dev;
    member_read(&dev, skb, dev);

    char* head;
    u16 mac_header;

    member_read(&head,       skb, head);
    member_read(&mac_header, skb, mac_header);

    // Compute IP Header address
    #define MAC_HEADER_SIZE 14;
    char* ip_header_address = head + mac_header + MAC_HEADER_SIZE;

    bpf_probe_read(&evt.ip_version, sizeof(u8), ip_header_address);
    evt.ip_version = evt.ip_version >> 4 & 0xf;

    struct iphdr iphdr;
    bpf_probe_read(&iphdr, sizeof(iphdr), ip_header_address);

    // Load protocol and address
    u8 icmp_offset_from_ip_header = iphdr.ihl * 4;
    evt.saddr[0] = iphdr.saddr;
    evt.daddr[0] = iphdr.daddr;

    if (iphdr.protocol != IPPROTO_ICMP) {
    return 0;
    }

    char* icmp_header_address = ip_header_address + icmp_offset_from_ip_header;
    struct icmphdr icmphdr;
    bpf_probe_read(&icmphdr, sizeof(icmphdr), icmp_header_address);

    // Filter ICMP echo request and echo reply
    if (icmphdr.type != ICMP_ECHO && icmphdr.type != ICMP_ECHOREPLY) {
        return 0;
    }

    // Get ICMP info
    evt.icmptype = icmphdr.type;

    // Load interface name
    bpf_probe_read(&evt.ifname, IFNAMSIZ, dev->name);

    // Send event to userland
    route_evt.perf_submit(ctx, &evt, sizeof(evt));

    return 0;
}

/**
  * Attach to Kernel Tracepoints
  */

TRACEPOINT_PROBE(net, netif_rx) {
    return do_trace(args, (struct sk_buff*)args->skbaddr);
}

TRACEPOINT_PROBE(net, net_dev_queue) {
    return do_trace(args, (struct sk_buff*)args->skbaddr);
}

TRACEPOINT_PROBE(net, napi_gro_receive_entry) {
    return do_trace(args, (struct sk_buff*)args->skbaddr);
}

TRACEPOINT_PROBE(net, netif_receive_skb_entry) {
    return do_trace(args, (struct sk_buff*)args->skbaddr);
}
'''

IFNAMSIZ = 16 # uapi/linux/if.h

class RouteEvt(ct.Structure):
    _fields_ = [
           ("ifname",  ct.c_char * IFNAMSIZ),
           ("ip_version",  ct.c_ulonglong),
           ("saddr",       ct.c_ulonglong * 2),
           ("daddr",       ct.c_ulonglong * 2),
           ("icmptype",  ct.c_ulonglong),
    ]

def event_printer(cpu, data, size):
    # Decode event
    event = ct.cast(data, ct.POINTER(RouteEvt)).contents
    if(event.ifname):
        # Print event
        saddr = inet_ntop(AF_INET, pack("=I", event.saddr[0]))
        daddr = inet_ntop(AF_INET, pack("=I", event.daddr[0]))
        if event.icmptype in [8, 128]:
            direction = "request"
        elif event.icmptype in [0, 129]:
            direction = "reply"
        print("%s,%s,%s,%s,%s" % (datetime.datetime.now(), direction, event.ifname, saddr, daddr))


if __name__ == "__main__":
    b = BPF(text=bpf_text)
    b["route_evt"].open_perf_buffer(event_printer)
    print("%s,%s,%s,%s,%s" % ("timestamp", "type", "interface", "source-ip", "destination-ip"))
    while True:
        b.kprobe_poll()

