import yaml
import ansible_runner
import pexpect
import time,ipaddress
from utils import *

VM_PASSWORD = 'test'
VM_USERNAME = 'test'

def create_cgw_router(gateway_data: dict, gateway_type: str) -> None:
#Create the CGW router VM instance based on the inputs
    logging.info("Creating a gateway VM for {vm_name}".format(vm_name=gateway_data["name"]))
    var = {"vm_name" : gateway_data["name"], "networks" : gateway_data["network_list"], "device_type": gateway_type}

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)

    r = ansible_runner.run(private_data_dir='/home/csc792/eBPF-xDP/southbound', playbook='vm_create.yml')
    
    logging.info("VM creation status for {vm_name} is {status}".format(vm_name=gateway_data["name"], status = r.status))
    gateway_data.update({"device_type": gateway_type})
    configure_cgw_router(gateway_data)


def configure_cgw_router(gateway_data: dict) -> None:

    def configure_ssh():

        print(">> Console session started for the VM : " + gateway_data["name"])
        child = pexpect.spawnu("virsh console " + gateway_data["name"] + " --force")
        time.sleep(2)
        child.sendline(VM_USERNAME)
        time.sleep(2)
        child.sendline(VM_PASSWORD)
        time.sleep(2)
        child.sendline("sudo su")
        time.sleep(2)
        child.sendline(VM_PASSWORD)
        print("waiting for ssh to start")
        print(">> Configuring SSH server ")
        child.sendline('sudo apt install --assume-yes openssh-server')
        time.sleep(10)
        child.sendline('sudo apt remove --assume-yes openssh-server')
        time.sleep(40)
        child.sendline('sudo apt install --assume-yes openssh-server')
        time.sleep(10)
        print(">> SSH configuration complete")

    def configure_dhcp() -> None:
        var = gateway_data

        first_ip = []
        range_start_ip = []
        range_stop_ip = []
        subnet_masks = []
        default_gateway = []

        for i in gateway_data["ip_list"]:
         net_obj = ipaddress.ip_network(i,False)
         first_ip.append(str(net_obj[1]) + "/" + i.split("/")[1])
         range_start_ip.append(str(net_obj[2]))
         range_stop_ip.append(str(net_obj[-2]))
         subnet_masks.append(str(net_obj.netmask))
         default_gateway.append(str(net_obj[1]))

        logging.debug("IP information for {vm_name}the gateway extracted: first_ip: {first_ip}, range_start_ip: {range_start_ip}, range_stop_ip: {range_stop_ip}, subnet_mask :{subnet_masks}, default_gateway:{default_gateway}".format(
            vm_name=gateway_data["name"],
            first_ip=first_ip,
            range_start_ip=range_start_ip,
            range_stop_ip=range_stop_ip,
            subnet_masks=subnet_masks,
            default_gateway=default_gateway
        ))
        var.update({"first_ip": first_ip, "range_start_ip":range_start_ip, "range_stop_ip":range_stop_ip, "subnet_mask":subnet_masks, "default_gateway":default_gateway})
		
        with open('../southbound/vars.yml', 'w') as f:
            yaml.dump(var, f)
        
        generate_host_file(cgw_ip[1], "../southbound/inventory")

        r = ansible_runner.run(private_data_dir='/home/csc792/eBPF-xDP/southbound', playbook='gateway_configure.yml', verbosity = 1)


    #cgw_ip = get_dhcp_lease(gateway_data["name"],"default")
    
    # Wait for the cgw to come up
    time.sleep(90)
    logging.info("Starting configuration on the client")

    configure_ssh()
    logging.info("Starting DHCP configuration on the client")
    cgw_ip = get_dhcp_lease(gateway_data["name"],"default")
    configure_dhcp()
 
''' 
def main():
    params = {"name": "tena669-cgw","network_list": ["t2","t3","pgw-net"],"ip_list": ["192.168.5.1/24","192.168.10.1/24"]}
    create_cgw_router(params)

if __name__ == '__main__':
    main()

'''
