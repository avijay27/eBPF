import yaml
import ansible_runner
import json
import pprint

def delete_vm(vm_name: str) -> None:
    

    var = {"vm_name": vm_name}
    print(var)

    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)
        ansible_runner.run(private_data_dir='/home/csc792/eBPF-xDP/southbound', playbook='vm_delete.yml')


            






with open("data/tenant_parsed.json") as f:
    data = json.load(f)
   # pprint.pprint(data)
    for tenant in data.keys():
        for vm_name in data[tenant]["VM"].keys():
        
            delete_vm(vm_name)

