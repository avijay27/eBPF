import yaml
import ansible_runner
import json
import pprint
import pexpect
import time
import logging
from utils import *


def create_container(container_data: dict) -> None:


    var = {"name": container_data['name'], "network_list": container_data['network_list']}
    print(var);
    with open('../southbound/vars.yml', 'w') as f:
        yaml.dump(var, f)

    r = ansible_runner.run(private_data_dir='../southbound', playbook='container_create.yml', quiet=True)

    if r.rc == 0:
        logging.info(f"container creation was successful for {container_data['name']}")
        return 1
    else:
        logging.info(f"container creation was not successful for {container_data['name']}")
        return 0
