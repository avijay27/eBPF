import subprocess,time

with open('/home/input.txt') as f:
  lines = f.read()
  for line in lines.split('\n'):
        if line == '':
          out = subprocess.run('ping 8.8.8.8 -c 1', shell=True)
          print(out)
          continue
        out = subprocess.run('ping ' + line + ' -c 1', shell=True)
        print(out)
        time.sleep(0.2)

