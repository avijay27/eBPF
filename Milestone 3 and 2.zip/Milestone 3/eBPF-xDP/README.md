
Prerequisites for running the files:

requirements :
pip install ansible_runner
ansible-galaxy collection install community.libvirt
sudo apt-get install sshpass

sudo apt install python3-pip
pip install pandas
sudo apt-get install libguestfs-tools
ubuntu base-vm

Instructions for Execution:

1. create the base-vm using an ubuntu image and shut down the VM

2. Modif the tenant.json file to add the VM details according to the template

3. Run parse_input.py file 
